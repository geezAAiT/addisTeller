class Constants {
  static String baseUrl = 'http://192.168.122.1:6002';
}
